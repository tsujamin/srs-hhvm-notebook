<?php

require "vendor/autoload.php";

$parser        = new PHPParser_Parser(new PHPParser_Lexer);
$prettyPrinter = new PHPParser_PrettyPrinter_Default;

$code = file_get_contents("vendor/dflydev/markdown/src/dflydev/markdown/MarkdownParser.php");

try {
    $stmts = $parser->parse($code);
    $results = '<?php ' . $prettyPrinter->prettyPrint($stmts);
    echo $results;
} catch (PHPParser_Error $e) {
    echo 'Parse Error: ', $e->getMessage();
}
