<?php

require "vendor/autoload.php";

use dflydev\markdown\MarkdownExtraParser;

$mdp = new MarkdownExtraParser();

$test_doc2 = file_get_contents("otaku.page");

$i = 0;
while ($i < 8) {
    $mdp->transformMarkdown($test_doc2);
    $i++;
}
